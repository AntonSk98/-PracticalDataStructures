package main.java.test;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        // write your code here
        //данные добавляются последовательно: ФИО, телефон
        LinkedList<String> data=new LinkedList<String>();
        data.add("Иванов И.И.");
        data.add("89995656908");
        data.add("Иванов И.И.");
        data.add("89996748503");
        data.add("Иванов И.И.");
        data.add("89525439856");
        data.add("Инна А.А.");
        data.add("23584");
        data.add("Инна А.А.");
        data.add("8124563205");
        data.add("Владислав Е.С.");
        data.add("89343452946");
        data.add("Екатерина Б.Б.");
        data.add("89342435935");
        data.add("Екатерина Б.Б.");
        data.add("89435093694");
        Map<String, List<String>> map = new LinkedHashMap<String, List<String>>(); //для хранения данных ФИО->телефоны использовал Map,
        //где в качестве ключа указано ФИО(тип String) в качестве коллекции для хранения телефонов указан ArrayList
        //так как при вводе имени нам необходимо получать номера телефонов, то предпочтительнее использовать ArrayList
        //нежели LinkedList. В ArrayList метод get(int index) отрабатывает за время O(1)
        //также для метода add(E element) время добавления O(1), однако в случае если элементов(номеров) будет больше 10
        //то время вставки возрастет до O(n), т.к лист должен произвести две операции resize и copy уже хранящихся данных
        //в надежде что у одного пользователя не может быть больше чем 10 телефонных номер было выбрано использован
        //ArrayList, тогда метода add(E element) и get(int index) отработают за время 0(1)
        while (!data.isEmpty()) {
            String key = data.remove(); //вернулся 1 удаленный элемент теперь 1 элементом является строка с номером
            if (!map.containsKey(key))
                map.put(key, new ArrayList<String>()); // создали для ключа(имени) новый ArrayList
            map.get(key).add(data.remove()); //добавили 1 удаленный элемент (который сейчас является уже номером)
        }
        System.out.println("Введите ФИО"); //просим ввести ФИО
        Scanner name = new Scanner(System.in);
        String typedName = name.nextLine();
        if(map.containsKey(typedName)){ //здесь проверка есть ли телефон в "БД"
            for(int i=0; i<map.get(typedName).size(); i++)
                System.out.println(map.get(typedName).get(i)); //если да то выводит все элементы ключа по индексу
        }else
            System.out.println("Данного пользователя нет в БД");
    }
}
